<?php
declare(strict_types=1);

require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

const DATA_DIR = __DIR__ . '/data';
const GUARD = "<?php exit; ?>\n"; // data files are .php: if opened by URL they output nothing

function out(int $code, array $body): void {
    http_response_code($code);
    echo json_encode($body, JSON_UNESCAPED_UNICODE);
    exit;
}

function readStore(string $name, $default) {
    $f = DATA_DIR . '/' . $name . '.php';
    if (!is_file($f)) return $default;
    $raw = file_get_contents($f);
    if ($raw === false) return $default;
    if (strncmp($raw, GUARD, strlen(GUARD)) === 0) $raw = substr($raw, strlen(GUARD));
    $v = json_decode($raw, true);
    return is_array($v) ? $v : $default;
}

/** Read-modify-write under an exclusive lock. */
function updateStore(string $name, $default, callable $fn) {
    if (!is_dir(DATA_DIR) && !mkdir(DATA_DIR, 0750, true)) out(500, ['error' => 'Нет доступа к папке data']);
    $f = DATA_DIR . '/' . $name . '.php';
    $h = fopen($f, 'c+');
    if (!$h) out(500, ['error' => 'Не удалось открыть файл данных']);
    flock($h, LOCK_EX);
    $raw = stream_get_contents($h);
    if ($raw !== false && strncmp($raw, GUARD, strlen(GUARD)) === 0) $raw = substr($raw, strlen(GUARD));
    $cur = $raw ? json_decode($raw, true) : null;
    if (!is_array($cur)) $cur = $default;
    $next = $fn($cur);
    ftruncate($h, 0);
    rewind($h);
    fwrite($h, GUARD . json_encode($next, JSON_UNESCAPED_UNICODE));
    fflush($h);
    flock($h, LOCK_UN);
    fclose($h);
    return $next;
}

/** Telegram Mini App initData check: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app */
function verifyInitData(string $initData): ?array {
    if ($initData === '' || BOT_TOKEN === '' || str_starts_with(BOT_TOKEN, 'ВСТАВЬТЕ')) return null;
    $pairs = [];
    foreach (explode('&', $initData) as $part) {
        $kv = explode('=', $part, 2);
        if (count($kv) !== 2) continue;
        $pairs[urldecode($kv[0])] = urldecode($kv[1]);
    }
    if (empty($pairs['hash'])) return null;
    $hash = $pairs['hash'];
    unset($pairs['hash']);
    ksort($pairs);
    $lines = [];
    foreach ($pairs as $k => $v) $lines[] = $k . '=' . $v;
    $secret = hash_hmac('sha256', BOT_TOKEN, 'WebAppData', true);
    $calc = hash_hmac('sha256', implode("\n", $lines), $secret);
    if (!hash_equals($calc, $hash)) return null;
    if (isset($pairs['auth_date']) && time() - (int)$pairs['auth_date'] > MAX_AGE) return null;
    $user = json_decode($pairs['user'] ?? 'null', true);
    return is_array($user) && isset($user['id']) ? $user : null;
}

function defaultTeam(): array {
    $admins = [];
    for ($i = 1; $i <= 7; $i++) $admins[] = ['id' => 'a' . $i, 'name' => 'Администратор ' . $i];
    return [
        'admins' => $admins,
        'slots' => [
            ['id' => 'bol-d', 'club' => 'Большакова, 99А', 'short' => 'Большакова', 'label' => 'День', 'from' => '10:00', 'to' => '22:00'],
            ['id' => 'bol-n', 'club' => 'Большакова, 99А', 'short' => 'Большакова', 'label' => 'Ночь', 'from' => '22:00', 'to' => '10:00'],
            ['id' => 'che-d', 'club' => 'Чернышевского, 4А', 'short' => 'Чернышевского', 'label' => 'День', 'from' => '10:00', 'to' => '22:00'],
        ],
    ];
}

function validWeek($w): bool { return is_string($w) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $w) === 1; }
function validKey($k): bool { return is_string($k) && preg_match('/^\d{4}-\d{2}-\d{2}_[a-z0-9-]{1,20}$/', $k) === 1; }
function adminIds(array $team): array { return array_map(fn($a) => $a['id'], $team['admins']); }

function cleanCells($cells, array $team, string $week): array {
    $ids = adminIds($team);
    $out = [];
    if (!is_array($cells)) return $out;
    foreach ($cells as $k => $v) {
        if (!validKey($k) || !is_string($v) || !in_array($v, $ids, true)) continue;
        $out[$k] = $v;
    }
    return $out;
}

function cleanTeam($t): ?array {
    if (!is_array($t) || !is_array($t['admins'] ?? null) || !is_array($t['slots'] ?? null)) return null;
    if (count($t['admins']) < 1 || count($t['admins']) > 20 || count($t['slots']) < 1 || count($t['slots']) > 10) return null;
    $admins = [];
    foreach ($t['admins'] as $a) {
        if (!is_array($a) || !preg_match('/^a\d{1,2}$/', (string)($a['id'] ?? ''))) return null;
        $name = trim((string)($a['name'] ?? ''));
        if ($name === '' || mb_strlen($name) > 40) return null;
        $admins[] = ['id' => $a['id'], 'name' => $name];
    }
    $slots = [];
    foreach ($t['slots'] as $s) {
        if (!is_array($s) || !preg_match('/^[a-z0-9-]{1,20}$/', (string)($s['id'] ?? ''))) return null;
        foreach (['from', 'to'] as $f) if (!preg_match('/^\d{1,2}:\d{2}$/', (string)($s[$f] ?? ''))) return null;
        $row = ['id' => $s['id']];
        foreach (['club', 'short', 'label'] as $f) {
            $v = trim((string)($s[$f] ?? ''));
            if ($v === '' || mb_strlen($v) > 60) return null;
            $row[$f] = $v;
        }
        $row['from'] = $s['from'];
        $row['to'] = $s['to'];
        $slots[] = $row;
    }
    return ['admins' => $admins, 'slots' => $slots];
}

// ---------- request ----------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(405, ['error' => 'Только POST']);
$req = json_decode(file_get_contents('php://input') ?: '', true);
if (!is_array($req)) out(400, ['error' => 'Неверный запрос']);

if (BOT_TOKEN === '' || str_starts_with(BOT_TOKEN, 'ВСТАВЬТЕ')) out(500, ['error' => 'Не задан токен бота в config.php']);

$user = verifyInitData((string)($req['initData'] ?? ''));
if (!$user) out(401, ['error' => 'Откройте график через Telegram-бота']);

$uid = (int)$user['id'];
$setup = count(OWNER_IDS) === 0;
$canEdit = in_array($uid, OWNER_IDS, true);
$canView = $canEdit || count(VIEWER_IDS) === 0 || in_array($uid, VIEWER_IDS, true);
$me = ['id' => $uid, 'name' => trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''))];

if (!$canView) out(403, ['error' => 'Нет доступа к графику', 'me' => $me]);

$action = (string)($req['action'] ?? '');
$team = readStore('team', defaultTeam());

if ($action === 'state') {
    $week = $req['week'] ?? '';
    if (!validWeek($week)) out(400, ['error' => 'Неверная неделя']);
    $w = readStore('week-' . $week, ['cells' => []]);
    out(200, ['team' => $team, 'cells' => (object)cleanCells($w['cells'] ?? [], $team, $week), 'canEdit' => $canEdit, 'setup' => $setup, 'me' => $me]);
}

if (!$canEdit) out(403, ['error' => 'Изменять график может только руководитель']);

if ($action === 'setCell') {
    $week = $req['week'] ?? '';
    $key = $req['key'] ?? '';
    $adm = $req['admin'] ?? null;
    if (!validWeek($week) || !validKey($key)) out(400, ['error' => 'Неверные данные']);
    if ($adm !== null && !in_array($adm, adminIds($team), true)) out(400, ['error' => 'Нет такого администратора']);
    $w = updateStore('week-' . $week, ['cells' => []], function ($cur) use ($key, $adm) {
        $cells = is_array($cur['cells'] ?? null) ? $cur['cells'] : [];
        if ($adm === null) unset($cells[$key]); else $cells[$key] = $adm;
        return ['cells' => $cells];
    });
    out(200, ['cells' => (object)cleanCells($w['cells'], $team, $week)]);
}

if ($action === 'setWeek') {
    $week = $req['week'] ?? '';
    if (!validWeek($week)) out(400, ['error' => 'Неверная неделя']);
    $cells = cleanCells($req['cells'] ?? [], $team, $week);
    updateStore('week-' . $week, ['cells' => []], fn($cur) => ['cells' => $cells]);
    out(200, ['cells' => (object)$cells]);
}

if ($action === 'setTeam') {
    $t = cleanTeam($req['team'] ?? null);
    if (!$t) out(400, ['error' => 'Проверьте имена и время смен']);
    updateStore('team', defaultTeam(), fn($cur) => $t);
    out(200, ['team' => $t]);
}

out(400, ['error' => 'Неизвестное действие']);
